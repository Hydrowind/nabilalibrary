CREATE TRIGGER `update_stock` AFTER INSERT ON `transactions`
 FOR EACH ROW BEGIN
	IF NEW.type = 'peminjaman' THEN 
    	UPDATE books SET quantity = quantity-1 WHERE id = NEW.book_id;
	ELSEIF NEW.type = 'pengembalian' THEN 
    	UPDATE books SET quantity = quantity+1 WHERE id = NEW.book_id;
	END IF;
END

CREATE TRIGGER `update_stock2` AFTER UPDATE ON `transactions`
 FOR EACH ROW BEGIN
	IF NEW.type = 'peminjaman' THEN 
    	UPDATE books SET quantity = quantity-1 WHERE id = NEW.book_id;
	ELSEIF NEW.type = 'pengembalian' THEN 
    	UPDATE books SET quantity = quantity+1 WHERE id = NEW.book_id;
	END IF;
END
