/assets folder used for user client template view
/ folder used for admin template view
