<footer id="footer" data-aos="fade-up" data-aos-easing="ease-in-out" data-aos-duration="500">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6 footer-info">
            <div class="logo">
              <a href="/"><img src="/images/logo.png" alt="" class="img-fluid"></a>
            </div>
            <br>
            <br>
            <p>Motto Yayasan Perguruan Ksatrya Lima Satu adalah Unggul dalam Prestasi, Santun dalam Bertindak, Professional dalam Pelayanan</p>
            <!-- <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div> -->
          </div>

          <dic class="col-lg-4"></dic>
          
          <div class="col-lg-4 col-md-6 footer-links">
            <h4>Contact Info</h4>
            <ul>
              <li><i class="bx bx-map"></i> <a href="#">Jl. Percetakan Negara No.D232, Jakarta Pusat, DKI Jakarta</a></li>
              <li><i class="bx bx-phone"></i> <a href="#"> (021) 425 6689</a></li>
              <li><i class="bx bx-envelope"></i> <a href="#"> adminsma@yayasanksatrya.or.id</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Nabila</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div> -->
  </footer><!-- End Footer -->