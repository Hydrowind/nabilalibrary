
<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
    <thead>
        <tr>
            <th>ID</th>
            <th>Siswa</th>
            <th>Tanggal<br>Peminjaman</th>
            <th>Tanggal<br>Pengembalian</th>
            <th>Buku</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($d->id); ?></td>
            <td><?php echo e($d->user->name); ?></td>
            <td><?php echo e($d->date); ?></td>
            <td><?php echo e($d->return_date); ?></td>
            <td><?php echo e($d->book->title); ?></td>
            <td><?php echo e($d->type); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php /**PATH /media/herdhiantoko/Data/Projects/nabila8/resources/views/export.blade.php ENDPATH**/ ?>