<?php $__env->startSection('content'); ?>
<!-- DataTales Example -->

<?php
    $months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
?>

<div class="content-box-large">
    <div class="panel-body">
        <form action="" method="get">
            <select name="month" id="monthFilter" class="btn dropdown-toggle">
                <option value="">All</option>
                <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($i+1); ?>" <?php echo e(isset($_GET['month']) && $_GET['month'] == $i+1 ? "selected" : ""); ?>><?php echo e($month); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            
            <select name="year" id="yearFilter" class="btn dropdown-toggle">
                <option value="">All</option>
                <?php for($year = 2010 ; $year <= 2023 ; $year++): ?>
                    <option value="<?php echo e($year); ?>" <?php echo e(isset($_GET['year']) && $_GET['year'] == $year ? "selected" : ""); ?>><?php echo e($year); ?></option>
                <?php endfor; ?>
            </select>
            
            <input class="btn btn-primary" type="submit" name="action" value="Submit" />
            <!-- <input class="btn btn-danger" type="submit" name="action" value="Export PDF" /> -->

        </form> 

        <br></br>
        
        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered">
            <thead>
                <tr>
                  <th>ID</th>
                  <th>Siswa</th>
                  <th>Tanggal<br>Peminjaman</th>
                  <th>Tanggal<br>Pengembalian</th>
                  <th>Buku</th>
                  <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($d->id); ?></td>
                    <td><?php echo e($d->student->fullname); ?></td>
                    <td><?php echo e($d->date); ?></td>
                    <td><?php echo e($d->return_date); ?></td>
                    <td><?php echo e($d->book->title); ?></td>
                    <td><?php echo e($d->type); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/herdhiantoko/Data/Projects/nabila8/resources/views/report.blade.php ENDPATH**/ ?>