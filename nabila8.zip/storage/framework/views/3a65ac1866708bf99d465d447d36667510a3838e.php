
<?php $__env->startSection('content'); ?>

<!-- DataTales Example -->
<div class="content-box-large">
    <div class="card-body">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h2 class="m-0 font-weight-bold text-primary"><i class="fas fa-house-user"></i> Edit Data Baru</h2>
            </div>
            <div class="card-body">
            <form class="user" method="post" action="<?php echo e(route('transactions.update', $data->id)); ?>">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="type">Status</label>
                        <select name="type" id="type" class="form-control" placeholder="Type" required>
                            <option value="peminjaman" <?php if($data->type == "peminjaman"): ?> selected <?php endif; ?>>Peminjaman</option>
                            <option value="pengembalian" <?php if($data->type == "pengembalian"): ?> selected <?php endif; ?>>Pengembalian</option>
                        </select>
                    </div>
                    <div class="form-group" style="display: none;">
                        <label for="date">Date</label>
                        <input type="date" class="form-control" id="date"
                            placeholder="Masukkan Tanggal" name="date" value="<?php echo e($data->date); ?>" required>
                    </div>
                    <div class="form-group" style="display: none;">
                        <label for="book_id">Buku</label>
                        <select name="book_id" id="book_id" class="form-control" placeholder="Book" required>
                            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($book->id); ?>" <?php if($data->book_id == $book->id): ?> selected <?php endif; ?>><?php echo e($book->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group" style="display: none;">
                        <label for="user_id">User</label>
                        <select name="user_id" id="user_id" class="form-control" placeholder="User" required>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php if($data->user_id == $user->id): ?> selected <?php endif; ?>><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-user btn-block">
                        Submit
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/herdhiantoko/Data/Projects/nabila8/resources/views/pages/transaction/edit.blade.php ENDPATH**/ ?>