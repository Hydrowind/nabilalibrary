
<?php $__env->startSection('content'); ?>
<section class="breadcrumbs">
  <div class="container">

    <div class="d-flex justify-content-between align-items-center">
      <h2>Pencarian buku dengan kata kunci dari judul atau pengarang</h2>
      <form action="<?php echo e(route('search')); ?>" method="get">
        <div class="row">
          <!-- <label for="search" class="col-sm-2 col-form-label">Search</label> -->
          <div class="col-sm-10">
            <input type="text" class="form-control" name="keyword" id="keyword" placeholder="Masukkan Kata Kunci">
          </div>
          <div class="col-sm-2">
            <button type="submit" class="btn btn-primary">Cari</button>
          </div>
        </div>
      </form>
    </div>

  </div>
</section><!-- End About Us Section -->

<!-- ======= About Section ======= -->
<section class="about" data-aos="fade-up">
  <div class="container">

    <div class="row">
      <?php if(app('request')->input('keyword') != ''): ?>
      <p>Ditemukan <b><?php echo e(count($data)); ?></b> buku dari pencarian Anda melalui kata kunci <b> <?php echo e(app('request')->input('keyword')); ?> </b></p>
      <?php endif; ?>
      
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-3">
        <div class="card" style="width: 18rem; margin-bottom: 15px;">
          <img src="<?php echo e($book->coverUrl); ?>" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><?php echo e($book->title); ?></h5>
            <h6 class="card-subtitle mb-2 text-muted"><?php echo e($book->author); ?> - <?php echo e($book->year); ?></h6>
            <div class="row">
              <div class="col-md-6">
                <p class="card-subtitle mb-2 text-muted"><?php echo e($book->page); ?> Halaman</p>
              </div>
              <div class="col-md-6 text-end align-middle">
                <p class="badge rounded-pill bg-info">Sisa Stok Buku : <?php echo e($book->quantity); ?></p> <br>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </div>
</section><!-- End About Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/herdhiantoko/Data/Projects/nabila8/resources/views/search.blade.php ENDPATH**/ ?>